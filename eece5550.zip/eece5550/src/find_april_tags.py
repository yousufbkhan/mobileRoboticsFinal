import rospy
from std_msgs.msg import String
import numpy as np
import cv2
from cv_bridge import CvBridge
from nav_msgs.msg import OccupancyGrid
from nav_msgs.msg import Odometry
import tf
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal

map_resolution = 0.05000000074505806
first_trigger = True
occupancyMap = []
robot_pose = 0

def movebase_client():

    client = actionlib.SimpleActionClient('move_base',MoveBaseAction)
    client.wait_for_server()

    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id = "map"
    goal.target_pose.header.stamp = rospy.Time.now()
    goal.target_pose.pose.position.x = 0.5
    goal.target_pose.pose.orientation.w = 1.0

    client.send_goal(goal)
    wait = client.wait_for_result()
    if not wait:
        rospy.logerr("Action server not available!")
        rospy.signal_shutdown("Action server not available!")
    else:
        return client.get_result()

def explore_status(data):
    global first_trigger
    global occupancyMap
    global robot_pose
    if ((data.data == "Exploration finished.") and first_trigger):
        first_trigger = False
        rospy.loginfo("saving map")
        # get ocupancy map
        nparray = np.array(occupancyMap)
        occupancyMap = np.reshape(nparray, (384,384))

        # # get robot pose with respect to the map
        listener = tf.TransformListener()
        # listener.waitForTransform("map", "base_footprint", rospy.Time(), rospy.Duration(4.0))
        # map_pose = listener.transformPose("map", robot_pose)

        # with open('/home/linux/occupancymap.txt', 'w') as f:
        #     f.write(str(occupancyMap.tolist()))

        # robot_pose_str = "x: " + str(map_pose.pose.position.x) + " y: " +str(map_pose.pose.position.y) + " z: " + str(map_pose.pose.position.z)

        # with open('/home/linux/robotpose.txt', 'w') as f:
        #     f.write(robot_pose_str)

        result = movebase_client()
        if result:
            rospy.loginfo("Goal execution done!")
        

def get_map(data):
    global occupancyMap
    global first_trigger

    if (first_trigger):
        rospy.loginfo("updating map")
        occupancyMap = data.data

def get_robot_pose(data):
    global first_trigger
    global robot_pose

    if (first_trigger):
        rospy.loginfo("updating robot pose")
        robot_pose = data.pose
        # rospy.loginfo(str(robot_pose))


def find_april_tags():
    rospy.init_node('find_april_tags', anonymous=False)

    rospy.Subscriber("explore/status", String, explore_status)
    rospy.Subscriber("map", OccupancyGrid, get_map)
    rospy.Subscriber("odom", Odometry, get_robot_pose)
    
    rospy.spin()

if __name__ == '__main__':
    find_april_tags()
    
